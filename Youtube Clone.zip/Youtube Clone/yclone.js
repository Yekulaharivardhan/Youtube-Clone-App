const searchInput = document.querySelector("#search-input");

searchInput.addEventListener("keydown", function(event) {
    if(event.code === "Enter") 

    {
    search();}});

function search()
{
    const input = searchInput.value;
    window.location.href = "https://www.google.co.in/search?q=" + input + "&ei=-JQTYrmWKpfD3LUPssG4gA8&ved=0ahUKEwi58v7e9JD2AhWXIbcAHbIgDvAQ4dUDCA4&uact=5&oq=" + input + "&gs_lcp=Cgdnd3Mtd2l6EAMyCgguELEDENQCEEMyBAgAEEMyBAgAEEMyBAgAEEMyBAgAEEMyBAgAEEMyCgguELEDENQCEEMyBAgAEEMyBAgAEEMyCwguEIAEEMcBEK8BOgUIABCRAjoLCAAQgAQQsQMQgwE6EQguEIAEELEDEIMBEMcBEKMCOgsILhCABBCxAxCDAToICAAQsQMQgwE6CAgAEIAEELEDOgsILhCABBCxAxDUAjoFCAAQgAQ6CwguELEDENQCEJECOgcIABCxAxBDOgcIABCxAxAKOgcIABCABBAKOgUILhCABDoOCC4QgAQQxwEQowIQ1AJKBAhBGABKBAhGGABQAFjHKWDKLWgDcAF4AIABqAGIAZ8IkgEDMy42mAEAoAEBwAEB&sclient=gws-wiz"
}